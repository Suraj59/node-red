# Node-RED Server

A clean Node-RED server installation with Express.js backend.

## Features

- Clean Node-RED installation without sample flows
- Admin authentication enabled (username: admin, password: password)
- Express.js server integration
- Health check endpoint for deployment monitoring
- Graceful shutdown handling

## Local Development

1. Install dependencies:
   ```bash
   npm install
   ```

2. Start the server:
   ```bash
   npm start
   ```

3. Access Node-RED editor at: `http://localhost:3000/red`

## Deployment

### Railway Deployment

1. Create a Railway account at [railway.app](https://railway.app)
2. Install Railway CLI: `npm install -g @railway/cli`
3. Login: `railway login`
4. Deploy: `railway up`

### Manual Deployment Steps

1. Push your code to a Git repository (GitHub, GitLab, etc.)
2. Connect your repository to Railway
3. Railway will automatically detect the Node.js project and deploy it
4. Your Node-RED editor will be available at: `https://your-app.railway.app/red`

### Environment Variables

- `PORT`: Server port (automatically set by Railway)
- `NODE_RED_ADMIN_PASSWORD_HASH`: Bcrypt hash for admin password

## Security Notes

- Change the default admin password in production
- Generate a new password hash using: `node -e "console.log(require('bcryptjs').hashSync('your-password', 8))"`
- Set the `NODE_RED_ADMIN_PASSWORD_HASH` environment variable with your new hash

## API Endpoints

- `/` - Server status and information
- `/health` - Health check endpoint
- `/red` - Node-RED editor interface
- `/red/api` - Node-RED HTTP nodes endpoint