const http = require('http');
const express = require('express');
const RED = require('node-red');

// Create an Express app
const app = express();

// Create an HTTP server
const server = http.createServer(app);

// Node-RED settings
const settings = {
    httpAdminRoot: '/red',
    httpNodeRoot: '/red/api',
    userDir: './node-red-data',
    functionGlobalContext: {},
    logging: {
        console: {
            level: 'info',
            metrics: false,
            audit: false
        }
    },
    // Disable tours and sample flows for clean installation
    tours: false,
    welcomeDialog: false,
    // Security settings
    adminAuth: {
        type: 'credentials',
        users: [{
            username: 'admin',
            password: process.env.NODE_RED_ADMIN_PASSWORD_HASH || '$2b$08$zZWtXTja0fB1pzD4sHCMyOCMYz2Z6dNbM6tl8sJogENOMcxWV9DN.',
            permissions: '*'
        }]
    }
};

// Initialize Node-RED
RED.init(server, settings);

// Serve the editor UI from /red
app.use(settings.httpAdminRoot, RED.httpAdmin);

// Serve the HTTP nodes from /red/api
app.use(settings.httpNodeRoot, RED.httpNode);

// Basic route for the root path
app.get('/', (req, res) => {
    res.json({
        message: 'Node-RED Server is running',
        editor: 'Access the Node-RED editor at /red',
        status: 'Clean installation - no sample flows loaded',
        environment: process.env.NODE_ENV || 'development'
    });
});

// Health check endpoint for Railway
app.get('/health', (req, res) => {
    res.status(200).json({ status: 'healthy', timestamp: new Date().toISOString() });
});

const PORT = process.env.PORT || 3000;

// Start the server
server.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on port ${PORT}`);
    console.log(`Node-RED editor available at: http://localhost:${PORT}/red`);
    console.log('Login credentials: admin / password');
    
    // Start Node-RED runtime
    RED.start();
});

// Graceful shutdown
process.on('SIGTERM', () => {
    console.log('Received SIGTERM, shutting down gracefully...');
    RED.stop();
    server.close(() => {
        console.log('Server closed');
        process.exit(0);
    });
});

process.on('SIGINT', () => {
    console.log('Received SIGINT, shutting down gracefully...');
    RED.stop();
    server.close(() => {
        console.log('Server closed');
        process.exit(0);
    });
});